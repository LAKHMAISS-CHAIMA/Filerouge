import React, { useEffect, useState } from 'react';
import axios from 'axios';

function SubstanceLibrary() {
  const [substances, setSubstances] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('/api/substances')
      .then(res => {
        setSubstances(res.data);
        setLoading(false);
      })
      .catch(err => {
        setError('Erreur lors du chargement des substances');
        setLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-violet-100 to-green-100 py-12 px-4">
      <h1 className="text-3xl font-extrabold mb-8 text-center text-violet-800 drop-shadow">Bibliothèque de Substances</h1>
      {loading && <div className="text-center text-cyan-700">Chargement...</div>}
      {error && <div className="text-center text-red-500">{error}</div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {substances.map(sub => (
          <div key={sub._id} className="bg-white/80 rounded-2xl shadow-lg p-6 flex flex-col items-start border-t-4 border-cyan-300 hover:border-violet-400 transition-all">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-xl font-bold text-violet-700">{sub.nom}</span>
              <span className="bg-cyan-200 text-cyan-900 px-3 py-1 rounded-full font-mono text-sm ml-2">{sub.formule}</span>
            </div>
            <p className="text-gray-700 mb-4">{sub.description}</p>
            <button
              className="mt-auto bg-gradient-to-r from-cyan-400 via-violet-400 to-green-400 hover:from-cyan-500 hover:to-green-500 text-white px-4 py-2 rounded-full shadow font-semibold transition-all duration-200"
            >
              Voir les détails
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SubstanceLibrary;

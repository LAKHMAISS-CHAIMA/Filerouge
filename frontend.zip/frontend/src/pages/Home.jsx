import React, { useRef } from 'react';
import SearchBar from '../components/SearchBar';

function Home() {
  const searchRef = useRef(null);

  const handleStartClick = () => {
    if (searchRef.current) {
      searchRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex flex-col items-center text-center px-4 mt-16 mb-10">
        <h1 className="text-4xl font-extrabold mb-4 text-[#4070f4]">Bienvenue sur ChemLab Sim</h1>
        <p className="text-lg text-gray-700 mb-8">
          Explorez la base de données PubChem, recherchez des substances chimiques, consultez leurs propriétés et lancez vos simulations de réactions en toute simplicité.
        </p>
        <button
          onClick={handleStartClick}
          className="bg-[#4070f4] hover:bg-[#3050b4] text-white font-semibold py-3 px-8 rounded-full shadow transition-colors duration-200"
        >
          Commencer
        </button>
      </div>
      <div ref={searchRef} className="w-full flex flex-col items-center mt-12">
        <h2 className="text-2xl font-bold mb-6 text-[#4070f4]">Recherche PubChem</h2>
        <SearchBar />
      </div>
    </div>
  );
}

export default Home;

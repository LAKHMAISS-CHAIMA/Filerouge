import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Admin() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (!user || user.role !== "Admin") {
      navigate("/");
      return;
    }
    fetch("/api/users", {
      headers: { Authorization: `Bearer ${user.token}` },
    })
      .then((res) => res.json())
      .then((data) => {
        setUsers(data);
        setLoading(false);
      })
      .catch(() => {
        setError("Erreur lors du chargement des utilisateurs.");
        setLoading(false);
      });
  }, [navigate]);

  if (loading) return <div className="p-8 text-center">Chargement...</div>;
  if (error) return <div className="p-8 text-red-600">{error}</div>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-violet-100 to-green-100 flex flex-col items-center py-12 px-4">
      <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl p-8 w-full max-w-3xl flex flex-col items-center border border-cyan-200 relative">
        <h2 className="text-2xl font-extrabold text-violet-800 mb-6">Gestion des utilisateurs</h2>
        <table className="w-full text-left bg-white/80 rounded-xl shadow">
          <thead>
            <tr>
              <th className="px-4 py-2">Nom</th>
              <th className="px-4 py-2">Email</th>
              <th className="px-4 py-2">Rôle</th>
              <th className="px-4 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id} className="border-b last:border-b-0">
                <td className="px-4 py-2">{u.firstname} {u.lastname}</td>
                <td className="px-4 py-2">{u.email}</td>
                <td className="px-4 py-2">{u.role}</td>
                <td className="px-4 py-2 flex gap-2">
                  <button className="bg-cyan-400 hover:bg-cyan-500 text-white px-3 py-1 rounded">Modifier</button>
                  <button className="bg-red-400 hover:bg-red-500 text-white px-3 py-1 rounded">Supprimer</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Admin; 
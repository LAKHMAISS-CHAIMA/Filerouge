import React, { useState, useEffect } from 'react';

const fakeHistory = [
  {
    id: 1,
    titre: 'Synthèse de l’eau',
    date: '2024-05-01',
    substances: ['H₂', 'O₂'],
    resultat: 'H₂O formé avec succès.'
  },
  {
    id: 2,
    titre: 'Neutralisation acide-base',
    date: '2024-05-03',
    substances: ['HCl', 'NaOH'],
    resultat: 'NaCl et H₂O produits.'
  },
  {
    id: 3,
    titre: 'Combustion du glucose',
    date: '2024-05-05',
    substances: ['C₆H₁₂O₆', 'O₂'],
    resultat: 'CO₂ et H₂O dégagés.'
  },
];

function History() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setTimeout(() => {
      setHistory(fakeHistory);
      setLoading(false);
    }, 800);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-100 via-cyan-100 to-green-100 py-12 px-4">
      <h1 className="text-3xl font-extrabold mb-8 text-center text-cyan-800 drop-shadow">Historique des expériences</h1>
      {loading && <div className="text-center text-cyan-700">Chargement...</div>}
      {error && <div className="text-center text-red-500">{error}</div>}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {history.map(exp => (
          <div key={exp.id} className="bg-white/80 rounded-2xl shadow-lg p-6 flex flex-col border-t-4 border-violet-300 hover:border-cyan-400 transition-all">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-lg font-bold text-cyan-700">{exp.titre}</span>
              <span className="bg-violet-200 text-violet-900 px-3 py-1 rounded-full font-mono text-xs ml-2">{exp.date}</span>
            </div>
            <div className="mb-2">
              <span className="font-semibold text-violet-700">Substances :</span>
              <ul className="list-disc list-inside ml-2">
                {exp.substances.map((s, i) => (
                  <li key={i} className="inline-block bg-cyan-100 text-cyan-800 px-2 py-1 rounded-full text-xs mr-2 mb-1">{s}</li>
                ))}
              </ul>
            </div>
            <div className="text-green-700 font-medium mt-2">{exp.resultat}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default History; 
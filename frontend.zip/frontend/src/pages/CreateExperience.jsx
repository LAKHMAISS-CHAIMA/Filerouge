import React, { useState } from 'react';

function CreateExperience() {
  const [titre, setTitre] = useState("");
  const [description, setDescription] = useState("");
  const [resultat, setResultat] = useState("");
  const [substances, setSubstances] = useState([{ value: "" }]);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubstanceChange = (idx, e) => {
    const newSubs = [...substances];
    newSubs[idx].value = e.target.value;
    setSubstances(newSubs);
  };

  const handleAddSubstance = () => {
    setSubstances([...substances, { value: "" }]);
  };

  const handleRemoveSubstance = (idx) => {
    if (substances.length === 1) return;
    setSubstances(substances.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setSuccess(true);
      setLoading(false);
      setTitre("");
      setDescription("");
      setResultat("");
      setSubstances([{ value: "" }]);
    }, 1200);
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center py-12 px-2 bg-gradient-to-br from-cyan-100 via-violet-100 to-green-100 animate-gradient-move">
      <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl p-8 w-full max-w-2xl flex flex-col items-center border border-cyan-200 relative">
        <h1 className="text-3xl font-extrabold mb-2 mt-2 text-violet-800 drop-shadow">Créer une expérience personnalisée</h1>
        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-6 mt-4">
          <div>
            <label className="block font-semibold mb-2 text-violet-700">Titre de l'expérience :</label>
            <input
              type="text"
              value={titre}
              onChange={e => setTitre(e.target.value)}
              className="border-2 border-cyan-300 focus:border-violet-500 bg-white/70 rounded-xl px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-violet-300 shadow-sm transition-all duration-200"
              required
            />
          </div>
          <div>
            <label className="block font-semibold mb-2 text-violet-700">Substances impliquées :</label>
            {substances.map((sub, idx) => (
              <div key={idx} className="flex items-center gap-2 mb-2 transition-all">
                <input
                  type="text"
                  value={sub.value}
                  onChange={e => handleSubstanceChange(idx, e)}
                  placeholder={`Nom ou formule de la substance #${idx + 1}`}
                  className="border-2 border-cyan-300 focus:border-violet-500 bg-white/70 rounded-xl px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-violet-300 shadow-sm transition-all duration-200"
                  required
                />
                <button
                  type="button"
                  onClick={() => handleRemoveSubstance(idx)}
                  className="text-yellow-500 hover:text-red-600 text-2xl font-bold px-2 rounded-full transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-yellow-300"
                  disabled={substances.length === 1}
                  title="Supprimer cette substance"
                >
                  &minus;
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={handleAddSubstance}
              className="mt-2 bg-gradient-to-r from-cyan-400 via-violet-400 to-green-400 hover:from-cyan-500 hover:to-green-500 text-white px-4 py-2 rounded-full shadow-md font-semibold transition-all duration-200"
            >
              + Ajouter une substance
            </button>
          </div>
          <div>
            <label className="block font-semibold mb-2 text-violet-700">Description :</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="border-2 border-cyan-300 focus:border-violet-500 bg-white/70 rounded-xl px-3 py-2 w-full min-h-[80px] focus:outline-none focus:ring-2 focus:ring-violet-300 shadow-sm transition-all duration-200"
              required
            />
          </div>
          <div>
            <label className="block font-semibold mb-2 text-violet-700">Résultat attendu :</label>
            <textarea
              value={resultat}
              onChange={e => setResultat(e.target.value)}
              className="border-2 border-cyan-300 focus:border-violet-500 bg-white/70 rounded-xl px-3 py-2 w-full min-h-[60px] focus:outline-none focus:ring-2 focus:ring-violet-300 shadow-sm transition-all duration-200"
              required
            />
          </div>
          <button
            type="submit"
            className="bg-gradient-to-r from-violet-500 via-cyan-400 to-green-400 hover:from-violet-600 hover:to-green-500 text-white font-bold py-3 px-8 rounded-full shadow-lg text-lg transition-all duration-200"
            disabled={loading}
          >
            {loading ? 'Création en cours...' : 'Créer l\'expérience'}
          </button>
        </form>
        {success && (
          <div className="bg-green-100 border border-green-300 text-green-800 rounded-xl px-6 py-4 mt-6 text-center font-semibold animate-fade-in">
            Expérience créée avec succès !
          </div>
        )}
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 1s;
        }
      `}</style>
    </div>
  );
}

export default CreateExperience; 
import React, { useState } from 'react';
define('react-chartjs-2', () => {});
define('chart.js/auto', () => {});
let Pie;
try {
  Pie = require('react-chartjs-2').Pie;
  require('chart.js/auto');
} catch (e) {
  Pie = null;
}

function SimulationPage() {
  const [substances, setSubstances] = useState([{ value: '' }]);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubstanceChange = (idx, e) => {
    const newSubs = [...substances];
    newSubs[idx].value = e.target.value;
    setSubstances(newSubs);
  };

  const handleAddSubstance = () => {
    setSubstances([...substances, { value: '' }]);
  };

  const handleRemoveSubstance = (idx) => {
    if (substances.length === 1) return;
    setSubstances(substances.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);
    setTimeout(() => {
      setResult({
        substances: substances.map((s, i) => ({ name: s.value, index: i + 1 })),
        proportions: substances.map(() => 1),
      });
      setLoading(false);
    }, 1200);
  };

  // Couleurs chimiques pour le graphique
  const chartColors = [
    '#06b6d4', // cyan
    '#a78bfa', // violet
    '#34d399', // vert
    '#fde047', // jaune
    '#818cf8', // indigo
    '#f472b6', // rose
    '#fbbf24', // orange
  ];

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center py-12 px-2 bg-gradient-to-br from-cyan-400 via-violet-500 to-green-300 animate-gradient-move">
      <div className="bg-white/30 backdrop-blur-md rounded-3xl shadow-2xl p-8 w-full max-w-2xl flex flex-col items-center border border-white/40 relative">
        <div className="absolute -top-16 left-1/2 -translate-x-1/2 flex items-center justify-center">
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
            <ellipse cx="40" cy="60" rx="28" ry="12" fill="#a5f3fc" fillOpacity="0.7"/>
            <rect x="32" y="10" width="16" height="40" rx="8" fill="#a78bfa"/>
            <ellipse cx="40" cy="50" rx="16" ry="8" fill="#34d399" fillOpacity="0.7"/>
            <ellipse cx="40" cy="20" rx="8" ry="4" fill="#fde047" fillOpacity="0.8"/>
          </svg>
        </div>
        <h1 className="text-3xl font-extrabold mb-2 mt-8 text-violet-800 drop-shadow">Simuler une Réaction Chimique</h1>
        <p className="text-md text-cyan-900 mb-6">Ajoutez les substances impliquées et lancez la simulation !</p>
        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-6 mt-2">
          <div>
            <label className="block font-semibold mb-2 text-violet-700">Substances impliquées :</label>
            {substances.map((sub, idx) => (
              <div key={idx} className="flex items-center gap-2 mb-2 transition-all">
                <input
                  type="text"
                  value={sub.value}
                  onChange={e => handleSubstanceChange(idx, e)}
                  placeholder={`Nom ou formule de la substance #${idx + 1}`}
                  className="border-2 border-cyan-300 focus:border-violet-500 bg-white/70 rounded-xl px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-violet-300 shadow-sm transition-all duration-200"
                  required
                />
                <button
                  type="button"
                  onClick={() => handleRemoveSubstance(idx)}
                  className="text-yellow-500 hover:text-red-600 text-2xl font-bold px-2 rounded-full transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-yellow-300"
                  disabled={substances.length === 1}
                  title="Supprimer cette substance"
                >
                  &minus;
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={handleAddSubstance}
              className="mt-2 bg-gradient-to-r from-cyan-400 via-violet-400 to-green-400 hover:from-cyan-500 hover:to-green-500 text-white px-4 py-2 rounded-full shadow-md font-semibold transition-all duration-200"
            >
              + Ajouter une substance
            </button>
          </div>
          <button
            type="submit"
            className="bg-gradient-to-r from-violet-500 via-cyan-400 to-green-400 hover:from-violet-600 hover:to-green-500 text-white font-bold py-3 px-8 rounded-full shadow-lg text-lg transition-all duration-200"
            disabled={loading}
          >
            {loading ? (
              <span className="flex items-center gap-2"><span className="animate-spin inline-block w-5 h-5 border-2 border-t-2 border-t-yellow-400 border-cyan-300 rounded-full"></span> Simulation...</span>
            ) : 'Simuler la réaction'}
          </button>
        </form>
        {error && <div className="text-red-500 mt-4">{error}</div>}
        {result && (
          <div className="bg-white/80 rounded-xl shadow p-6 mt-8 w-full text-center text-lg text-violet-800 border border-violet-200 animate-fade-in flex flex-col items-center">
            <h2 className="text-xl font-bold mb-4 text-cyan-700">Résultats de la simulation</h2>
            {/* Tableau des substances */}
            <table className="w-full mb-6 border-separate border-spacing-y-2">
              <thead>
                <tr>
                  <th className="px-4 py-2 text-left text-violet-700">#</th>
                  <th className="px-4 py-2 text-left text-cyan-700">Substance</th>
                </tr>
              </thead>
              <tbody>
                {result.substances.map((s, i) => (
                  <tr key={i} className="bg-violet-50/60 hover:bg-cyan-50 rounded-xl">
                    <td className="px-4 py-2 font-semibold text-violet-600">{s.index}</td>
                    <td className="px-4 py-2 text-cyan-900">{s.name}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {/* Graphique camembert */}
            {Pie ? (
              <div className="w-full flex justify-center">
                <div className="w-64 h-64">
                  <Pie
                    data={{
                      labels: result.substances.map(s => s.name),
                      datasets: [
                        {
                          data: result.proportions,
                          backgroundColor: result.substances.map((_, i) => chartColors[i % chartColors.length]),
                          borderWidth: 2,
                          borderColor: '#fff',
                        },
                      ],
                    }}
                    options={{
                      plugins: {
                        legend: {
                          display: true,
                          position: 'bottom',
                          labels: { color: '#312e81', font: { size: 14 } },
                        },
                      },
                    }}
                  />
                </div>
              </div>
            ) : (
              <div className="text-gray-500 mt-4">(Graphique camembert disponible si Chart.js est installé)</div>
            )}
          </div>
        )}
      </div>
      <style>{`
        @keyframes gradient-move {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient-move {
          background-size: 200% 200%;
          animation: gradient-move 8s ease-in-out infinite;
        }
        .animate-fade-in {
          animation: fadeIn 1s;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}

export default SimulationPage;

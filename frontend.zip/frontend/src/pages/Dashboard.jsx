import React, { useState } from 'react';

const fakeUser = {
  nom: 'Marie Curie',
  email: 'marie.curie@chimie.com',
  role: 'Chercheur',
  avatar: 'https://ui-avatars.com/api/?name=Marie+Curie&background=06b6d4&color=fff&size=128',
};

const fakeFavorites = [
  { id: 1, type: 'Substance', label: 'Eau (H₂O)' },
  { id: 2, type: 'Expérience', label: 'Synthèse de l’eau' },
  { id: 3, type: 'Substance', label: 'Glucose (C₆H₁₂O₆)' },
];

function Dashboard() {
  const [logoutMsg, setLogoutMsg] = useState("");

  const handleLogout = () => {
    setLogoutMsg("Vous avez été déconnecté(e).");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-violet-100 to-green-100 flex flex-col items-center py-12 px-4">
      <div className="bg-white/40 backdrop-blur-md rounded-3xl shadow-2xl p-8 w-full max-w-xl flex flex-col items-center border border-cyan-200 relative">
        <img src={fakeUser.avatar} alt="avatar" className="w-28 h-28 rounded-full border-4 border-cyan-300 shadow mb-4" />
        <h2 className="text-2xl font-extrabold text-violet-800 mb-1">{fakeUser.nom}</h2>
        <div className="text-cyan-800 font-medium mb-2">{fakeUser.email}</div>
        <div className="bg-cyan-200 text-cyan-900 px-4 py-1 rounded-full font-semibold mb-6">{fakeUser.role}</div>
        <button
          onClick={handleLogout}
          className="mb-8 bg-gradient-to-r from-violet-500 via-cyan-400 to-green-400 hover:from-violet-600 hover:to-green-500 text-white font-bold py-2 px-8 rounded-full shadow-lg text-lg transition-all duration-200"
        >
          Se déconnecter
        </button>
        {logoutMsg && <div className="bg-green-100 border border-green-300 text-green-800 rounded-xl px-6 py-3 mb-4 text-center font-semibold animate-fade-in">{logoutMsg}</div>}
        <div className="w-full mt-2">
          <h3 className="text-xl font-bold text-violet-700 mb-4">Favoris</h3>
          <ul className="flex flex-col gap-3">
            {fakeFavorites.map(fav => (
              <li key={fav.id} className="flex items-center gap-3 bg-white/70 rounded-xl px-4 py-3 shadow border-l-4 border-cyan-300">
                <span className="font-semibold text-cyan-700">{fav.type} :</span>
                <span className="text-violet-800">{fav.label}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 1s;
        }
      `}</style>
    </div>
  );
}

export default Dashboard; 
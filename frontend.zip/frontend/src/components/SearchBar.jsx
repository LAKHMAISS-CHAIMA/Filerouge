import React, { useState } from 'react';

function SearchBar() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleInputChange = (e) => {
    setQuery(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setError(null);
    setResults(null);
    try {
      const res = await fetch(`/api/pubchem/search/${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error("Substance non trouvée");
      const data = await res.json();
      setResults(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center w-full">
      <form
        onSubmit={handleSubmit}
        className="p-5 overflow-hidden w-[60px] h-[60px] hover:w-[270px] bg-[#4070f4] shadow-[2px_2px_20px_rgba(0,0,0,0.08)] rounded-full flex group items-center hover:duration-300 duration-300"
      >
        <div className="flex items-center justify-center fill-white">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            id="Isolation_Mode"
            data-name="Isolation Mode"
            viewBox="0 0 24 24"
            width="22"
            height="22"
          >
            <path
              d="M18.9,16.776A10.539,10.539,0,1,0,16.776,18.9l5.1,5.1L24,21.88ZM10.5,18A7.5,7.5,0,1,1,18,10.5,7.507,7.507,0,0,1,10.5,18Z"
            ></path>
          </svg>
        </div>
        <input
          type="text"
          value={query}
          onChange={handleInputChange}
          placeholder="Rechercher une substance..."
          className="outline-none text-[20px] bg-transparent w-full text-white font-normal px-4"
        />
      </form>
      {loading && <div className="text-blue-600 mt-2">Recherche...</div>}
      {error && <div className="text-red-500 mt-2">{error}</div>}
      {results && results.PC_Compounds && (
        <div className="bg-white rounded shadow p-4 mt-2 w-full max-w-md">
          <h3 className="font-bold text-lg mb-2">Résultats :</h3>
          {results.PC_Compounds.map((compound, idx) => (
            <div key={idx} className="mb-2 border-b pb-2 last:border-b-0 last:pb-0">
              <div><span className="font-semibold">Nom :</span> {query}</div>
              {compound.props && compound.props.find(p => p.urn && p.urn.label === "Molecular Formula") && (
                <div>
                  <span className="font-semibold">Formule :</span> {compound.props.find(p => p.urn && p.urn.label === "Molecular Formula").value.sval}
                </div>
              )}
              <div><span className="font-semibold">CID :</span> {compound.id && compound.id.id && compound.id.id.cid}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default SearchBar;

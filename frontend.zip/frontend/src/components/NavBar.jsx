import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";

function getUserRole() {
  try {
    const user = JSON.parse(localStorage.getItem("user"));
    return user?.role;
  } catch {
    return undefined;
  }
}

const dashArrays = [
  "0 2 8 73.3 8 10.7",    // Accueil
  "0 12.6 9.5 49.3 9.5 31.6", // Substances
  "0 24.5 8.5 27.5 8.5 55.5", // Simuler
  "0 18 8 20 8 80", // Créer Expérience
  "0 34.7 6.9 10.2 6.9 76",   // Historique
  "0 10 10 10 10 90", // Contact
  "0 5 10 10 10 95", // Dashboard
];

export default function Navbar() {
  const [hovered, setHovered] = useState(null);
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navItems = [
    { label: "Accueil", to: "/" },
    { label: "Substances", to: "/substances" },
    { label: "Simuler", to: "/simulation" },
    { label: "Créer Expérience", to: "/create-experience" },
    { label: "Historique", to: "/history" },
    { label: "Contact", to: "/contact" },
    { label: "Dashboard", to: "/dashboard" },
  ];
  const isAdmin = getUserRole() === "Admin";

  return (
    <nav className="w-full flex flex-col items-center">
      {/* Mobile menu button */}
      <div className="w-full flex justify-end md:hidden px-4 pt-4">
        <button
          className="p-2 rounded-lg bg-cyan-100/70 border border-cyan-200 shadow-md focus:outline-none"
          onClick={() => setOpen(!open)}
          aria-label="Ouvrir le menu"
        >
          <svg width="28" height="28" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
      {/* Navbar links */}
      <div
        className={`relative w-full max-w-3xl mx-auto my-4
          ${open ? "flex" : "hidden"} md:flex flex-row items-center justify-around transition-all duration-300`}
        style={{ zIndex: 20 }}
      >
        <div className="absolute inset-0 bg-white/60 backdrop-blur-lg border border-cyan-200 shadow-xl flex flex-row justify-around items-center p-2 rounded-2xl w-full h-full" />
        <ul className="flex flex-col md:flex-row w-full h-full items-center justify-around z-10">
          {navItems.map((item, idx) => {
            const isActive = location.pathname === item.to;
            return (
              <li key={item.label} className="w-full md:w-auto">
                <Link
                  to={item.to}
                  className={`
                    flex items-center justify-center
                    w-full md:w-auto
                    px-6 py-3 md:px-7 md:py-2
                    text-base md:text-lg font-bold rounded-xl
                    transition duration-200 outline-none
                    focus:ring-2 focus:ring-cyan-400
                    ${isActive
                      ? "bg-gradient-to-r from-cyan-300 via-violet-200 to-green-200 text-violet-900 shadow-lg scale-105"
                      : "text-cyan-900 hover:bg-cyan-100/70 hover:text-violet-700"}
                  `}
                  onMouseEnter={() => setHovered(idx)}
                  onMouseLeave={() => setHovered(null)}
                  onClick={() => setOpen(false)}
                >
                  {item.label}
                </Link>
              </li>
            );
          })}
          {isAdmin && (
            <li className="w-full md:w-auto">
              <Link
                to="/admin"
                className={`
                  flex items-center justify-center
                  w-full md:w-auto
                  px-6 py-3 md:px-7 md:py-2
                  text-base md:text-lg font-bold rounded-xl
                  transition duration-200 outline-none
                  focus:ring-2 focus:ring-cyan-400
                  ${location.pathname === "/admin"
                    ? "bg-gradient-to-r from-cyan-300 via-violet-200 to-green-200 text-violet-900 shadow-lg scale-105"
                    : "text-cyan-900 hover:bg-cyan-100/70 hover:text-violet-700"}
                `}
                onClick={() => setOpen(false)}
              >
                Admin
              </Link>
            </li>
          )}
        </ul>
        <svg
          className="absolute inset-0 pointer-events-none hidden md:block"
          width="100%"
          height="70"
          viewBox="0 0 700 70"
        >
          <rect
            x="0"
            y="0"
            width="700"
            height="70"
            fill="transparent"
            stroke="#06b6d4"
            strokeWidth="4"
            rx="22"
            style={{
              transition: "stroke-dasharray 0.5s, stroke-dashoffset 0.5s",
              strokeDashoffset: hovered !== null ? 0 : 5,
              strokeDasharray:
                hovered !== null ? dashArrays[hovered % dashArrays.length] : "0 0 10 40 10 40",
            }}
          />
        </svg>
      </div>
    </nav>
  );
}
import express from "express";
import Substance from "../models/Substance.js";
const router = express.Router();

router.get("/substances", async (req, res) => {
  const substances = await Substance.find();
  res.json(substances);
});

export default router; 
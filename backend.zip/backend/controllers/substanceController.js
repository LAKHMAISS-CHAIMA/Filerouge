export const getAllSubstances = async (req, res) => {
  res.status(501).json({ message: "Non implémenté." });
};

export const addSubstance = async (req, res) => {
  res.status(501).json({ message: "Non implémenté." });
};

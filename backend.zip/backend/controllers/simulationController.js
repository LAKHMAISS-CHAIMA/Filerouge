export const simulateReaction = async (req, res) => {
  res.status(501).json({ message: "Simulation non implémentée." });
};
